var dotX = 300;
var dotY = 300;
var enX = 100;
var enY = 100;
var score = 0;
var dotSize = 60;
var enSize = 1;
var gameover = 'False';

function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(115);
  circ();
  textSize(24);
  fill(0);
  text('Score: ' + score, 260, 585)
}

function circ() {
  if (gameover == 'False') {
    var disttoen = dist(enX, enY, mouseX, mouseY);
    line(mouseX, mouseY, dotX, dotY)
    fill('green');
    ellipse(dotX, dotY, dotSize, dotSize);
    ellipse(mouseX, mouseY, 15, 15);
    var disttodot = dist(dotX, dotY, mouseX, mouseY);
    if (disttodot < dotSize / 2 + 7.5) {
      dotX = random(40, 560);
      dotY = random(40, 560);
      score = score + 1;
      dotSize = dotSize - 0.5
      enX = random(80, 520);
      enY = random(80, 520);
      enSize = enSize + 1
      if(enSize > 74){
        enSize = 75;   
      }
    }
    if (dotSize < 10.1) {
      dotSize = 10;
    }
    if(score > 24){
      fill('red');
      ellipse(enX, enY, enSize, enSize);
      if(disttoen < enSize / 2 + 7.5){
        gameover = 'True';
      }
    }
  }else{
    text('Game Over', 248, 560)
  }
}